import { fazChamadaNoFirebase } from './service.js';

const page = () => {
    const root = document.createElement('div');
    root.innerHTML = `
        <button>click para salvar</button>
        <div data-status>batata</div>
    `;

    const button = root.querySelector('button');
    const status = root.querySelector('[data-status]');
    
    button.addEventListener('click', () => {
        // status.innerHTML = 'salvo';
        fazChamadaNoFirebase()
        .then(() => {
            status.innerHTML = 'salvo';    
        })
    });

    return root;
}

export default page;