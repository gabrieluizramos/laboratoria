/**
 * @jest-environment jsdom
 */

import page from './page';
import { fazChamadaNoFirebase } from './service';

jest.mock('./service');

const immediate = jest.requireActual('timers').setImmediate;
const flushPromises = () => new Promise(immediate)

describe('Page', () => {
   it('Deve iniciar com um status padrão', () => {
      const element = page();
      const status = element.querySelector('[data-status]');

      expect(status.innerHTML).toEqual('batata');
   });
   it('Deve mudar o texto do status após o click', async () => {
      fazChamadaNoFirebase.mockResolvedValueOnce();
      
      const element = page();
      
      const button = element.querySelector('button');
      button.click();
      
      await flushPromises();
      
      const status = element.querySelector('[data-status]');
      
      expect(status.innerHTML).toEqual('salvo');
   });
});