import page from './page.js';

const body = document.body;
const element = page();
body.append(element);