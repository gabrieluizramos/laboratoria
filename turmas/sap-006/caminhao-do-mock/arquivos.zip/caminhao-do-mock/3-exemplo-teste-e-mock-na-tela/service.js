export const fazChamadaNoFirebase = () => {
    return new Promise(resolve => {
        setTimeout(() => {
            resolve();
        }, 2000);
    });
}