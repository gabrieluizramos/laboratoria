import { jogoMuitoDoido } from './jogo.js';

const numeroDoJogador = process.argv[2] // 5
const resultado = jogoMuitoDoido(numeroDoJogador);

console.log(resultado);