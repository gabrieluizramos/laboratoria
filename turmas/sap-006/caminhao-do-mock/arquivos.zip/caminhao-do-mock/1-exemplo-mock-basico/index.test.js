import { jogoMuitoDoido }  from './jogo';
import { numeroAleatorio } from './aleatorio';

// jest.mock
jest.mock('./aleatorio');
// mock tava aqui em cima

describe('jogoMuitoDoido', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('jogoMuitoDoido deve retornar mensagem de sucesso, caso o numero seja maior que o aleatorio', () => {
        numeroAleatorio.mockReturnValueOnce(3);
        const numeroEscolhido = 5;
        const mensagem = jogoMuitoDoido(numeroEscolhido);

        expect(mensagem).toEqual('Ganhou :)');
        expect(numeroAleatorio).toHaveBeenCalledTimes(1);
    });
    it('jogoMuitoDoido deve retornar mensagem de erro, caso o numero seja menor que o aleatorio', () => {
        numeroAleatorio.mockReturnValueOnce(5);
        const numeroEscolhido = 2;
        const mensagem = jogoMuitoDoido(numeroEscolhido);

        expect(mensagem).toEqual('Perdeu :(');
        expect(numeroAleatorio).toHaveBeenCalledTimes(1);
    });
    it('jogoMuitoDoido deve retornar mensagem de empate, caso o numero seja igual que o aleatorio', () => {
        numeroAleatorio.mockReturnValueOnce(3);
        const numeroEscolhido = 3;
        const mensagem = jogoMuitoDoido(numeroEscolhido);

        expect(mensagem).toEqual('Empate :|');
        expect(numeroAleatorio).toHaveBeenCalledTimes(1);

    });
});