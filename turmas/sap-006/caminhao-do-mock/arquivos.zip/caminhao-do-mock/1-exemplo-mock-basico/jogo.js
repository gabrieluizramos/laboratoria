import { numeroAleatorio } from './aleatorio.js';

export const jogoMuitoDoido = (numero) => {
    const aleatorio = numeroAleatorio();
    console.log('Numero escolhido foi ', numero);
    console.log('Numero aleatorio foi ', aleatorio);

    if (numero > aleatorio) {
        return 'Ganhou :)'
    } else if (numero < aleatorio) {
        return 'Perdeu :('
    } else {
        return 'Empate :|'
    }
};