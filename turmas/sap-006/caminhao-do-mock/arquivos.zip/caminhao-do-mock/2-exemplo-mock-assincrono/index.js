import { jogoMuitoDoido } from './jogo.js';

const numeroDoJogador = process.argv[2]
jogoMuitoDoido(numeroDoJogador)
.then(resultado => {
    console.log(resultado);
});