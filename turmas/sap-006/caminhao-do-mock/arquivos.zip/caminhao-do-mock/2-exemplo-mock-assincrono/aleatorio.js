export const numeroAleatorio = () => {
    const aleatorio = Math.random() * 10;
    const inteiro = parseInt(aleatorio);
    
    return Promise.resolve(inteiro);
}