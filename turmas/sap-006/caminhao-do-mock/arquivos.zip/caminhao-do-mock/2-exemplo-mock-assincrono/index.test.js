import { jogoMuitoDoido }  from './jogo';
import { numeroAleatorio } from './aleatorio';

// jest.mock
jest.mock('./aleatorio');

describe('jogoMuitoDoido', () => {
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it('jogoMuitoDoido deve retornar mensagem de sucesso, caso o numero seja maior que o aleatorio', async () => {
        expect.assertions(2);
        
        numeroAleatorio.mockResolvedValueOnce(3);
        const numeroEscolhido = 5;
        const mensagem = await jogoMuitoDoido(numeroEscolhido);

        expect(mensagem).toEqual('Ganhou :)');
        expect(numeroAleatorio).toHaveBeenCalledTimes(1);
    });
    it('jogoMuitoDoido deve retornar mensagem de erro, caso o numero seja menor que o aleatorio', async () => {
        expect.assertions(2);

        numeroAleatorio.mockResolvedValueOnce(5);
        const numeroEscolhido = 2;
        const mensagem = await jogoMuitoDoido(numeroEscolhido);

        expect(mensagem).toEqual('Perdeu :(');
        expect(numeroAleatorio).toHaveBeenCalledTimes(1);
    });
    it('jogoMuitoDoido deve retornar mensagem de empate, caso o numero seja igual que o aleatorio', () => {
        expect.assertions(2);

        numeroAleatorio.mockResolvedValueOnce(3);
        const numeroEscolhido = 3;

        return jogoMuitoDoido(numeroEscolhido)
            .then((mensagem) => {
                expect(mensagem).toEqual('Empate :|');
                expect(numeroAleatorio).toHaveBeenCalledTimes(1);
            });
    });
});