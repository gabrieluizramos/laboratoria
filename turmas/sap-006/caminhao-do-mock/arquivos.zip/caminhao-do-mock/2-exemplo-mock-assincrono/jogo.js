import { numeroAleatorio } from './aleatorio.js';

export const jogoMuitoDoido = (numero) => {
    return numeroAleatorio()
    .then(aleatorio => {
        if (numero > aleatorio) {
            return 'Ganhou :)'
        } else if (numero < aleatorio) {
            return 'Perdeu :('
        } else {
            return 'Empate :|'
        }
    });
};